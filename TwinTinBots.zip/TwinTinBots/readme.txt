author : Benjamin Le Bastard, Luca Marinelli,Paul Bridier,Raphael Lefebvre
Equipe : 14
Date : 18/06/19

Pour compiler commande a taper : 
     javac @compil.list 
depuis le repertoire parent de TwinTinBots


Pour lancer le programme depuis le repertoire parent de TwinTinBots
    java TwinTinBots.ihm.Launcher

